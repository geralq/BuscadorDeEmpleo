package Modelo;

public class Mensaje{
    private String contenido;
}
