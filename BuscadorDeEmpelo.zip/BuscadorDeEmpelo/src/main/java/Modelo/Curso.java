package Modelo;

public class Curso{
    private final String profesión;
    private final Double precio;
    private final String centro;
    private final String provincia;
    private final int duraciónHoras;

    public Curso(String profesión, Double precio, String centro, String provincia, int duraciónHoras) {
        this.profesión = profesión;
        this.precio = precio;
        this.centro = centro;
        this.provincia = provincia;
        this.duraciónHoras = duraciónHoras;
    }

    public String getProfesión() {
        return profesión;
    }

    public Double getPrecio() {
        return precio;
    }

    public String getCentro() {
        return centro;
    }

    public String getProvincia() {
        return provincia;
    }

    public int getDuraciónHoras() {
        return duraciónHoras;
    }
}