package Modelo;

public class CV{

    private Boolean inglés;
    private int añosDeExperiencia;
    private String formación;
    private Boolean carnetDeConducir;

    public CV(Boolean inglés, int añosDeExperiencia, String formación, Boolean carnetDeConducir) {
        this.inglés = inglés;
        this.añosDeExperiencia = añosDeExperiencia;
        this.formación = formación;
        this.carnetDeConducir = carnetDeConducir;
    }

    public Boolean getInglés() {
        return inglés;
    }

    public int getAñosDeExperiencia() {
        return añosDeExperiencia;
    }

    public String getFormación() {
        return formación;
    }

    public Boolean getCarnetDeConducir() {
        return carnetDeConducir;
    }

    public void setInglés(Boolean inglés) {
        this.inglés = inglés;
    }

    public void setAñosDeExperiencia(int añosDeExperiencia) {
        this.añosDeExperiencia = añosDeExperiencia;
    }

    public void setFormación(String formación) {
        this.formación = formación;
    }

    public void setCarnetDeConducir(Boolean carnetDeConducir) {
        this.carnetDeConducir = carnetDeConducir;
    }

    
}