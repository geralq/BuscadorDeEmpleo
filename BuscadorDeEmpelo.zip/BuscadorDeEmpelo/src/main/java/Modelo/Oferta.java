package Modelo;

public class Oferta{
    public enum TipoDeContrato{ Fijo, Temporal, TiempoParcial}
    public final String profesión;
    public final Double sueldo;
    public final String empresa;
    public final String comunidadAutónoma;
    public TipoDeContrato contrato;

    public Oferta(String profesión, Double sueldo, String empresa, String comunidadAutónoma, TipoDeContrato contrato) {
        this.profesión = profesión;
        this.sueldo = sueldo;
        this.empresa = empresa;
        this.comunidadAutónoma = comunidadAutónoma;
        this.contrato = contrato;
    }
}