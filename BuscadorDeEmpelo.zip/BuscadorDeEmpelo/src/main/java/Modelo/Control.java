package Modelo;

import java.util.ArrayList;

import java.util.List;


public class Control {
    
    public User createUser(){
        List<Candidatura> candidaturas = new ArrayList<>();
        List<Curso> cursosApuntados = new ArrayList<>();
        List<Mensaje> mensajes = new ArrayList<>();
        User user = new User(" "," ",0, " ", null, candidaturas, cursosApuntados, mensajes);
        return user;
    }
    
    public List<Oferta> ofertList(){
        List<Oferta> listOferts = List.of(
                new Oferta("Profesor", 1500.00, "Colegio Ibéria", "Galicia", Oferta.TipoDeContrato.Fijo),
                new Oferta("Cajero", 1200.00, "HiperDino", "Las Palmas", Oferta.TipoDeContrato.Temporal),
                new Oferta("Informático", 1800.00, "Bankia", "Madrid", Oferta.TipoDeContrato.Fijo),
                new Oferta("Analísta de datos", 1900.00, "Repsol", "Asturias", Oferta.TipoDeContrato.Fijo),
                new Oferta("Administrativo", 1300.00, "Endesa", "Sevilla", Oferta.TipoDeContrato.TiempoParcial),
                new Oferta("Arquitécto", 1700.00, "A-cero", "Madrid", Oferta.TipoDeContrato.Temporal),
                new Oferta("Fontanero", 1050.00, "SevillaFontanería", "Sevilla", Oferta.TipoDeContrato.TiempoParcial),
                new Oferta("Charcutero", 1300.00, "Mercadona", "ComunidadValenciana", Oferta.TipoDeContrato.Temporal)
        );
        return listOferts;
    }
    
    public List<Curso> courseList(){
        List<Curso> listcourses = new ArrayList<>();
        return listcourses;
    }
}   