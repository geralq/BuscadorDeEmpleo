package Modelo;

public class Candidatura{
    public enum TipoDeEstado {Visto, Recibido, EnProcesoDeSelección}
    public final Oferta oferta;
    public TipoDeEstado estado;

    public Candidatura(Oferta oferta, TipoDeEstado estado) {
        this.oferta = oferta;
        this.estado = estado;
    }

    public Oferta getOferta() {
        return oferta;
    }

    public TipoDeEstado getEstado() {
        return estado;
    }

    public void setEstado(TipoDeEstado estado) {
        this.estado = estado;
    }
}