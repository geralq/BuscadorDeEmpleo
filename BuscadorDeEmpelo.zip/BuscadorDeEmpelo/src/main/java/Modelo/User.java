package Modelo;


import java.util.List;

public class User{
    private String nombre;
    private String apellidos;
    private int edad;
    private String password;
    public CV cv;
    private List<Candidatura> historialDeCandidaturas;
    private List<Curso> cursosApuntados;
    private List<Mensaje> mensajes;

    public User(String nombre, String apellidos, int edad, String password, CV cv, List<Candidatura> historialDeCandidaturas, List<Curso> cursosApuntados, List<Mensaje> mensajes) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.edad = edad;
        this.password = password;
        this.cv = cv;
        this.historialDeCandidaturas = historialDeCandidaturas;
        this.cursosApuntados = cursosApuntados;
        this.mensajes = mensajes;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public int getEdad() {
        return edad;
    }

    public String getPassword() {
        return password;
    }

    public CV getCv() {
        return cv;
    }

    public List<Candidatura> getHistorialDeCandidaturas() {
        return historialDeCandidaturas;
    }

    public List<Curso> getCursosApuntados() {
        return cursosApuntados;
    }

    public List<Mensaje> getMensajes() {
        return mensajes;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setCv(CV cv) {
        this.cv = cv;
    }

    public void setHistorialDeCandidaturas(List<Candidatura> historialDeCandidaturas) {
        this.historialDeCandidaturas = historialDeCandidaturas;
    }

    public void setCursosApuntados(List<Curso> cursosApuntados) {
        this.cursosApuntados = cursosApuntados;
    }

    public void setMensajes(List<Mensaje> mensajes) {
        this.mensajes = mensajes;
    }
}