package BuscadorDeEmpleoApp;

import GUI.JFrameBuscadorDeEmpleo;
import Modelo.Control;
import Modelo.Oferta;
import Modelo.User;
import java.util.List;


public class App {
    
    
    public static void main(String[] args) {
        Control control = new Control();
        
        List<Oferta> buscadorList = control.ofertList();
        User user = control.createUser();
        
        JFrameBuscadorDeEmpleo window = new JFrameBuscadorDeEmpleo(buscadorList, user);
        window.setVisible(true);
        window.setResizable(false);
    }
}
